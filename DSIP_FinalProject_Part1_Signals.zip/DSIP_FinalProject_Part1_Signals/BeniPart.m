%% Q1.1.1
f1 = 7/128;
f2 = 5/128;
fc = 50/128;
N = 1024;
n = 0:127;
w = linspace(0, 2*pi, N);
%declare the signal
x = cos(2*pi*(f1)*n) + cos(2*pi*(f2)*n);
x1 = cos(2*pi*fc*n);
y = x.*x1;
y_dtft = my_dtft(y,0,N);%calculating the DTFT
figure;
%plotting the dtft
plot(w,abs(y_dtft));
title("Magnitude of Y(w)");
xlabel("Frequency"); 
ylabel("Magnitude");
y_dft = fft(y, N); %calculatin the DFT
figure;%plotting the DFT
stem(w,abs(y_dft));
xlabel("Frequency"); 
ylabel("Magnitude");
title("|Y[k]|")
%% Q1.1.2
N = 1024;
n = 0:254;
f1 = 7/128;
f2 = 5/128;
fc = 50/128;
%declairing the signals 
w = linspace(0, 2*pi, N);
x = cos(2*pi*(f1)*n) + cos(2*pi*(f2)*n);
y = x.*cos(2*pi*fc*n);
y(180:256) = 0;%tailing with zeros
y2 = y;
%calculate DTFT of y2[n]
y2_dtft = my_dtft(y2,0,N);
figure;
plot(w,abs(y2_dtft));
title("Magnitude of Y2(w)");
xlabel("Frequency"); 
ylabel("Magnitude");
figure;
%calculating DFT of y2[n]
y2_dft = fft(y2,N);
stem(w,abs(y2_dft));
title("Magnitude of Y2[k]");
xlabel("Frequency"); 
ylabel("Magnitude");
%% Q1.2
h = [1 0 0 -0.5 0 0 0 0 0 0 0 0 0 0 0 0];
N = 16;
w = linspace(0,2*pi,N);
H = fft(h,N);%calculating DFT of h[n]
G = 1./H;
D = H.*G; %since convultion is multipying in frequency domain
g = my_IDFT(G); %inverse DFT
d = my_IDFT(D);
impz(d);%checking to see if d[n] is behaving like AP filter
Hw = my_dtft(h,0,N);
figure;
plot(w,Hw);
title("magnitude of DTFT of h[n]");
xlabel("Frequency");
ylabel("Magnitude");
figure;
stem(w,abs(H));
title("Magnitude of DFT of h[n]");
xlabel("Frequency");
ylabel("Magnitude");
figure;
stem(w,abs(D.*H));%plotting the the result of the magnitude of frequency response between h[n] and d[n]
title("Magnitude of DFT of d[n] multipied with DFT of h[n]");
xlabel("Frequency"); 
ylabel("Magnitude");

%is G(w) = 1/H(w)?
g_dtft = my_dtft(g,0,N);
h_dtft = my_dtft(h,0,N);
figure;%stemming both frequencies for comparison.
stem(w,g_dtft);
hold on;
stem(w,1./h_dtft);
title("comparison of G(w)= 1/H(w)");
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
legend("G(w)","1/H(w)");
%% Q2 Matlab Part 1 + 2
%to calculate N = 5 you can remove (%) symbol on line 92
N = 20;
 %N = 5;
n = 0 : N-1;
w = linspace(0,N,N);
x = 0.9 .^ n;
% plotting x[n]
figure;
plot(w,x);
title("x[n]");
xlabel("n"); 
ylabel("amplitude");
%implementing the equation we got from the analatical question which is
%IDFT
x_dtft = my_dtft(x,0,N);
Ck = fft(x);
x_gal = my_IDFT(Ck);
figure;
plot(w,real(x_gal));
title("xgal[n]");
xlabel("n"); 
ylabel("amplitude");
%% Q3.1
N = 128;
r = 0.9;
x = ones(1,N);
w = linspace(0,2*pi,N);
y = zeros(size(x));
%declairing the signal
for n = 1:length(x)
    if n == 1
        y(n) = -r^2 * 0 + x(n);
    elseif n == 2
        y(n) = -r^2 * 0 + x(n);
    else
        y(n) = -r^2 * y(n-2) + x(n);
    end
end
%calculating the DTFT of y
y_dtft = my_dtft(y,0,N);
figure;
plot(w,y_dtft);
title("DTFT of y[n]");
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%calculating the DFT of y
y_dft = fft(y);
figure;
plot(w,abs(y_dft));
title("DFT of y[n]");
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%% Q3.2
N = 128;
r = 0.9;
n = 0: N-1;
x = ones(1,N);
w = linspace(0,2*pi,N);
y = zeros(size(x));
for i = 1:length(x)
    if i == 1
        y(i) = -r^2 * 0 + x(i); 
    elseif i == 2
        y(i) = -r^2 * 0 + x(i);
    else
        y(i) = -r^2 * y(i-2) + x(i);
    end
end

Wn = zeros(1,N);
for i = 1:N
    Wn(i) = (1/(0.92^(i)))*y(i);
end
figure;
plot(n,Wn);
Wn_dft = fft(Wn);
figure;
plot(w,abs(Wn_dft));
title("DFT of W[n]");
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%% Q3.3
N = 128;
r = 0.5;
x = ones(1,N);
w = linspace(0,2*pi,N);
y = zeros(size(x));
j = 0 : N -1;
for n = 1:length(x)
    if n == 1
        y(n) = -r^2 * 0 + x(n);
    elseif n == 2
        y(n) = -r^2 * 0 + x(n);
    else
        y(n) = -r^2 * y(n-2) + x(n);
    end
end
y_dtft = my_dtft(y,0,N);
figure;
plot(w,y_dtft);
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
title("DTFT of y[n],3.3");
y_dft = fft(y);
figure;
plot(w,abs(y_dft));
title("DFT of y[n],3.3");
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%% Q3.4
N = 128;
r = 0.9;
n = 0: N-1;
x = ones(1,N);
w = linspace(0,2*pi,N);
y = zeros(size(x));
for i = 1:length(x)
    if i == 1
        y(i) = -r^2 * 0 + x(i);
    elseif i == 2
        y(i) = -r^2 * 0 + x(i);
    else
        y(i) = -r^2 * y(i-2) + x(i);
    end
end
Wn = (0.55.^(-n)).*y;
Wn_dft = fft(Wn);
figure;
plot(w,abs(Wn_dft));
title("DFT of w[n], 3.4");
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%% Q3.5
N = 128;
r = 0.5;
n = 0: N-1;
x = ones(1,N);
w = linspace(0,2*pi,N);
y = zeros(size(x));
for n = 1:length(x)
    if n == 1
        y(n) = -r^2 * 0 + x(n);
    elseif n == 2
        y(n) = -r^2 * 0 + x(n);
    else
        y(n) = -r^2 * y(n-2) + x(n);
    end
end
y = y + sqrt(0.1)*randn(1,128);
Wn = (0.55.*(-n)).*y;
y_dft = fft(y);
figure;
plot(w,abs(y_dft));
title("DFT of y[n] with noise");
Wn_dft = fft(Wn);
figure;
plot(w,abs(Wn_dft));
title("DFT of w[n],3.5,with noise");

%% Q4.1.1
N = 207;
P = zeros(1, N);
%declairing the signal using a loop
for k = 1:N
    sum = 0;
    for l = 0:8
        sum = sum + exp((-1i*2*pi/N)*23*l*k);
    end
    P(k) = sum;
end

% Plot the magnitude of the DFT
figure;
stem(abs(P));
title('Magnitude of DFT of p[n]');
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%% Q4.1.2
N = 414;
P = zeros(1, N);
for k = 1:N
    sum = 0;
    for l = 0:8
        sum = sum + exp((-1i*2*pi/N)*23*l*k);
    end
    P(k) = sum;
end
%P(208:414) = 0;
% Plot the magnitude of the DFT
figure;
stem(abs(P));
title('Magnitude of DFT of p[n] after tailing with zeros');
xlabel("Frequency (rad/sample)"); 
ylabel("Magnitude");
%% Q4.2.2
N = 10;
n = 0 : N - 1;
w = linspace(0,N,N);
% declairing x[n] and X[k]
x = cos(2*pi*n*4/10);
X = fft(x,N);
figure;
plot(w,abs(real(X)));
xlabel("Frequency"); 
ylabel("Magnitude");
title(" real ofX[k]");
N = 40;
n = 0: N-1;
w = linspace(0,N,N);
y = zeros(1, 40);
%declairing y[n] and Y[k] using x[n]
for i = 1 : N
    if (mod(i,4) == 0)
        y(i) = cos(2*pi*(i)*4/10)/4;
    end
end
Y = fft(y,N);
figure;
%ploting the real part of Y[k]
plot(w,abs(real(Y)));
title("real of Y[k]")
xlabel("Frequency"); 
ylabel("Magnitude");
%% Q5.1.1
b = [1 5.65685 16];
a = [1 -0.8 0.64];
figure;
freqz(b,a);
title("Frequency response");
figure;
zplane(b,a);
title("Pole-Zero map")
%% Q5.1.3 + Q5.1.4
numeratorAP = [1 5.65685 16];
denominatorAP = [16 5.65685 1];
numeratorMP = [16 5.65685 1];
denominatorMP = [0.64 -0.8 1];
%plotting frequency of Hap(z)
figure;
freqz(numeratorAP,denominatorAP);
%zero-pole map for the all-pass
figure;
zplane(numeratorAP,denominatorAP);
title("all pass");
%plotting frequency of Hmp(z)
figure;
freqz(numeratorMP,denominatorMP);
%zero-pole map for the minimum phase
figure;
zplane(numeratorMP,denominatorMP);
title("minimum phase");
%% Q5.2
N = 200;
b = [1 0 0 0 0 0 1];
w = linspace(0,2*pi,N);
figure;
impz(b);
title("Impulse Response");
figure;
% plott Frequency Response (Magnitude / Phase)
b_dtft = my_dtft([b 1],0,N);
freqz(b,1);
figure;
% Zero-Pole plot
zplane(b);