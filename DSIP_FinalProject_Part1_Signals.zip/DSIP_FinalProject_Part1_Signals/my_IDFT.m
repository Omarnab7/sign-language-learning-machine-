function [xn] = calcidft(Xk) %function to calculate IDFT 
    N=length(Xk); 
    for k=0:1:N-1 
        for n=0:1:N-1 
            p=exp(i*2*pi*n*k/N); 
            IT(k+1,n+1)=p; 
        end
    end
     disp('Transformation Matrix for IDFT'); 
    disp(IT); 
    xn = (IT*(Xk.'))/N; 
end